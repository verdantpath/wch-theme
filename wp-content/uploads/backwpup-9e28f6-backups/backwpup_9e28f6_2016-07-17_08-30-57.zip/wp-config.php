<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wch2016');

/** MySQL database username */
define('DB_USER', 'wch2016');

/** MySQL database password */
define('DB_PASSWORD', 'vWERYpp6!');

/** MySQL hostname */
define('DB_HOST', '68.178.143.154');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ';siRrRikk1k*C{/Qpb`2AF8~AN~/GJa2*dD$@+09o:1bL)*S>O.)d<r<(0}i(CN-');
define('SECURE_AUTH_KEY',  'kLW,JTUEet&}xn$Yj:`:gg!u9EH4{m ?b9xBR!8_4n1ZyVFrnF.H.myv36 yX8Rk');
define('LOGGED_IN_KEY',    'GHJ4,?jV0rnY7*zTTL>MIR`rGM5iJLdiWv-j`E+nMOUoSX:Tgfp[kx3g-JL/P8]Z');
define('NONCE_KEY',        '2%qx,qYLo#UOB*41>>SGgX5UT $.|wL5;*0NO1!sxrj9)&q)#N$Sl7%kF1JWotE;');
define('AUTH_SALT',        '?VkaP!9UPm9P<O4(a&f,HUxK0G%cqE?M]JO~0I}K~yUBg[1v>^9h$)+OD:A6d:=.');
define('SECURE_AUTH_SALT', 'K_nRtavN,VZ].d**?F8Hqo[R^KBouWJLaidcF;6HMaxzA9z Wh<3+?&+RR#=SOMX');
define('LOGGED_IN_SALT',   ')(1z@9+1&_57l~+=3K=-?F:N =gG*&Kd=QlKbDMp|h~*=VTQ@U[;Sv MObsY,> b');
define('NONCE_SALT',       'fk_S,TFjd3r8:.VwJT-;$M#ak`@^PK^3:fG`#w:QG~/Aj?SgZ Tznf{6>(}3Gd?J');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
